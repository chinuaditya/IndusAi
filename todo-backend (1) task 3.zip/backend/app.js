const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

// User model for authentication
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

const User = mongoose.model('User', userSchema);

// Todo model
const todoSchema = new mongoose.Schema({
    todo: { type: String, required: true },
    category: { type: String, required: true },
    priority: { type: String, required: true },
    status: { type: String, required: true },
    due_date: { type: Date, required: true },
});

const Todo = mongoose.model('Todo', todoSchema);

// Middleware to authenticate JWT
const authenticateJWT = (req, res, next) => {
    const token = req.header('Authorization')?.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// POST /register - Register a new user
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword });
    
    try {
        await newUser.save();
        res.status(201).send('User registered');
    } catch (error) {
        res.status(500).send('Error registering user');
    }
});

// POST /login - Authenticate user and return JWT
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.sendStatus(401);

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.sendStatus(401);

    const token = jwt.sign({ username: user.username }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
});

// GET todos
app.get('/todos', authenticateJWT, async (req, res) => {
    const { status, priority, category, search_q } = req.query;
    let query = {};
    
    if (status) query.status = status;
    if (priority) query.priority = priority;
    if (category) query.category = category;
    if (search_q) query.todo = { $regex: search_q, $options: 'i' };

    try {
        const todos = await Todo.find(query);
        res.json(todos);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

// GET todo by ID
app.get('/todos/:todoId', authenticateJWT, async (req, res) => {
    try {
        const todo = await Todo.findById(req.params.todoId);
        if (!todo) return res.status(404).send('Todo not found');
        res.json(todo);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

// GET agenda
app.get('/agenda', authenticateJWT, async (req, res) => {
    const { date } = req.query;
    if (!date) return res.status(400).send('Date is required');

    try {
        const todos = await Todo.find({ due_date: date });
        res.json(todos);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

// POST todos
app.post('/todos', authenticateJWT, async (req, res) => {
    const { todo, category, priority, status, due_date } = req.body;
    if (!todo || !category || !priority || !status || !due_date) {
        return res.status(400).send('All fields are required');
    }
    
    const newTodo = new Todo({ todo, category, priority, status, due_date });
    try {
        await newTodo.save();
        res.status(201).json(newTodo);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

// PUT todos by ID
app.put('/todos/:todoId', authenticateJWT, async (req, res) => {
    const { todo, category, priority, status, due_date } = req.body;
    try {
        const updatedTodo = await Todo.findByIdAndUpdate(
            req.params.todoId,
            { todo, category, priority, status, due_date },
            { new: true, runValidators: true }
        );
        if (!updatedTodo) return res.status(404).send('Todo not found');
        res.json(updatedTodo);
    } catch (error) {
        res.status(500).send('Server Error');
    }
});

// Error handling for invalid scenarios
app.use((req, res, next) => {
    res.status(404).send('Not Found');
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});